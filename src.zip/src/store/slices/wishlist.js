import { createSlice, current } from "@reduxjs/toolkit";

const initialState = JSON.parse(localStorage.getItem("wishlist")) || [];

const wishlistSlice = createSlice({
  name: "wishlist",
  initialState,
  reducers: {
    addToWishlist: (state, action) => {
      const { productId, selectedColor } = action.payload;

      // const index = state.findIndex(
      //   (item) =>
      //     item.productId === productId && item.selectedColor === selectedColor,
      // );

      state.push({ productId, selectedColor });
      console.log("added");

      console.log(current(state), "state");
      localStorage.setItem("wishlist", JSON.stringify(state));
    },
  },
});

export const { addToWishlist } = wishlistSlice.actions;
export default wishlistSlice.reducer;
