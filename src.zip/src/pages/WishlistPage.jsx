import { useSelector } from "react-redux";
import { useGetProductsQuery } from "../store/slices/products";

export default function Wishlist() {
  const wishlistItems = useSelector((state) => state.wishlist);
  console.log(wishlistItems, "wishlistItems");
  const { data: products } = useGetProductsQuery();

  const wishlistProducts =
    products?.filter((product) =>
      wishlistItems?.some((item) => item.productId === product.id),
    ) || [];
  console.log(wishlistProducts);
  return (
    <div>
      <h3>My Wishlist</h3>

      {wishlistProducts.map((product) => (
        <div key={product.id}>{product.name}</div>
      ))}
    </div>
  );
}
